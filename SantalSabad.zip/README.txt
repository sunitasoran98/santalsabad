SantalSabad: Santali Hindi English Dictionary (by BOSC)

Shabd jodna:
words.csv ko Excel/Google Sheet mein kholiye, nayi lines jodiye, phir "CSV UTF-8" format mein save karke isi naam (words.csv) se rakhiye.

Cloudflare Pages par deploy (santalsabad.pages.dev):
1. dash.cloudflare.com par login karein
2. Workers & Pages > Create > Pages > Upload assets
3. Project name: santalsabad
4. Is folder ki saari files upload karein > Deploy
